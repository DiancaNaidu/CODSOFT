/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taskfive_studentcourseregsys;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Dianca
 */
public class TaskFive_StudentCourseRegSys {

 private List<Course> courses;
    private List<Student> students;

    public TaskFive_StudentCourseRegSys() {
        this.courses = new ArrayList<>();
        this.students = new ArrayList<>();
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void displayCourses() {
        StringBuilder courseList = new StringBuilder("Available Courses:\n");
        for (Course course : courses) {
            courseList.append(course.toString()).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, courseList.toString(), "Course Listing", JOptionPane.INFORMATION_MESSAGE);
    }

    public void registerStudentForCourse(Student student, Course course) {
        if (student.registeredCourses.size() < 3 && course.capacity > 0) {
            student.registeredCourses.add(course);
            course.capacity--;
            JOptionPane.showMessageDialog(null, "Registration successful!", "Registration Status", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Registration unsuccessful. Either the course is full or the student has reached the maximum course limit.", "Registration Status", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void removeStudentFromCourse(Student student, Course course) {
        if (student.registeredCourses.contains(course)) {
            student.registeredCourses.remove(course);
            course.capacity++;
            JOptionPane.showMessageDialog(null, "Course removal successful!", "Removal Status", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Course removal unsuccessful. The student is not registered for this course.", "Removal Status", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        TaskFive_StudentCourseRegSys system = new TaskFive_StudentCourseRegSys();

        Course course1 = new Course("MATH", "Mathematics", "Advanced concepts in mathematics", 30, "Mon, Wed, Fri 10:00 AM");
        Course course2 = new Course("PROG", "Programming", "Programming in Java, Python and CSS", 25, "Tue, Thu 2:00 PM");
        Course course3 = new Course("CYBS", "Cyber Security", "Introduction to ethical hacking", 20, "Mon, Wed 1:30 PM");

        Student student1 = new Student("S001", "Henry Cavill");
        Student student2 = new Student("S002", "John Cena");

        system.addCourse(course1);
        system.addCourse(course2);
        system.addCourse(course3);

        system.addStudent(student1);
        system.addStudent(student2);

        int option;
        do {
            option = Integer.parseInt(JOptionPane.showInputDialog("Course Registration System:\n1. Display Courses\n2. Register Student for Course\n3. Remove Student from Course\n4. Exit"));
            switch (option) {
                case 1:
                    system.displayCourses();
                    break;
                case 2:
                    String studentID = JOptionPane.showInputDialog("Enter student ID:");
                    Student student = system.students.stream().filter(s -> s.studentID.equals(studentID)).findFirst().orElse(null);
                    if (student != null) {
                        String courseCode = JOptionPane.showInputDialog("Enter course code to register:");
                        Course course = system.courses.stream().filter(c -> c.code.equals(courseCode)).findFirst().orElse(null);
                        if (course != null) {
                            system.registerStudentForCourse(student, course);
                        } else {
                            JOptionPane.showMessageDialog(null, "Invalid course code.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid student ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    break;
                case 3:
                    String studentIDToRemove = JOptionPane.showInputDialog("Enter student ID:");
                    Student studentToRemove = system.students.stream().filter(s -> s.studentID.equals(studentIDToRemove)).findFirst().orElse(null);
                    if (studentToRemove != null) {
                        String courseCodeToRemove = JOptionPane.showInputDialog("Enter course code to remove:");
                        Course courseToRemove = system.courses.stream().filter(c -> c.code.equals(courseCodeToRemove)).findFirst().orElse(null);
                        if (courseToRemove != null) {
                            system.removeStudentFromCourse(studentToRemove, courseToRemove);
                        } else {
                            JOptionPane.showMessageDialog(null, "Invalid course code.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid student ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Exiting the program.", "Exit", JOptionPane.INFORMATION_MESSAGE);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (option != 4);
    }
}
