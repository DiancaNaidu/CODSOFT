/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taskone_numbergame;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author Dianca
 */
public class TaskOne_NumberGame {
    public static void main(String[] args) {
        numberGame();
    }

    public static int numberGame() {
        Random random = new Random();

        int lowest = 1;
        int highest = 100;
        int actualNumber = random.nextInt(highest - lowest + 1) + lowest;

        int maxAttempts = 10;
        int attempts = 0;
        int userScore = 0;

        while (attempts < maxAttempts) {
            String userInput = JOptionPane.showInputDialog(
                    "Guess the number between " + lowest + " and " + highest + ": ");
            int userGuess = Integer.parseInt(userInput);

            switch (Integer.compare(userGuess, actualNumber)) {
                case -1:
                    JOptionPane.showMessageDialog(null, "Too low! Try again.");
                    break;
                case 0:
                    JOptionPane.showMessageDialog(null,
                            "Congratulations! You guessed the correct number " + actualNumber + " in " + (attempts + 1) + " attempts.");
                    userScore++;
                    break;
                case 1:
                    JOptionPane.showMessageDialog(null, "Too high! Try again.");
                    break;
            }

            if (userGuess == actualNumber) {
                break;
            }

            attempts++;
        }

        String playAgain = JOptionPane.showInputDialog("Do you want to play again? (Y/N): ").toLowerCase();

        if (playAgain.equals("Y")) {
            userScore += numberGame();
        } else {
            JOptionPane.showMessageDialog(null, "Thanks for playing! Your final score is: " + userScore);
        }

        return userScore;
    }
}