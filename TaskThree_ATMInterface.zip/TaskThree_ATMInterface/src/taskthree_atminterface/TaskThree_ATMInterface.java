/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taskthree_atminterface;

import javax.swing.JOptionPane;

/**
 *
 * @author Dianca
 */
public class TaskThree_ATMInterface {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     double initial = Double.parseDouble(JOptionPane.showInputDialog("Enter initial account balance: $"));
        BankAccount userAccount = new BankAccount(initial);
        ATM atm = new ATM(userAccount);
        atm.runATM();
    }
    
}
