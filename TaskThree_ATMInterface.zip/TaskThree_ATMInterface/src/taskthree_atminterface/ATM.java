/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taskthree_atminterface;

import javax.swing.JOptionPane;

/**
 *
 * @author Dianca
 */
public class ATM {
     private BankAccount bankAccount;

    public ATM(BankAccount bankAccount) {
        this.bankAccount = bankAccount;
    }

    public void runATM() {
        while (true) {
            int choice = Integer.parseInt(JOptionPane.showInputDialog(
                    "Select an option:\n" +
                            "1. Check Balance\n" +
                            "2. Deposit\n" +
                            "3. Withdraw\n" +
                            "4. Exit"));

            switch (choice) {
                case 1:
                    checkBalance();
                    break;
                case 2:
                    deposit();
                    break;
                case 3:
                    withdraw();
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Exiting the ATM. Thank you!");
                    System.exit(0);
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please choose a valid option.");
            }
        }
    }

    private void checkBalance() {
        double balance = bankAccount.getBalance();
        JOptionPane.showMessageDialog(null, "Your current balance is: $" + balance);
    }

    private void deposit() {
        double amount = Double.parseDouble(JOptionPane.showInputDialog("Enter deposit amount: $"));
        if (amount > 0) {
            bankAccount.deposit(amount);
            JOptionPane.showMessageDialog(null, "Deposit successful. Your new balance is: $" + bankAccount.getBalance());
        } else {
            JOptionPane.showMessageDialog(null, "Invalid deposit amount. Please enter a positive value.");
        }
    }

    private void withdraw() {
        double amount = Double.parseDouble(JOptionPane.showInputDialog("Enter withdrawal amount: $"));
        if (bankAccount.withdraw(amount)) {
            JOptionPane.showMessageDialog(null, "Withdrawal successful. Your new balance is: $" + bankAccount.getBalance());
        } else {
            JOptionPane.showMessageDialog(null, "Withdrawal failed. Insufficient funds or invalid amount.");
        }
    }

}
