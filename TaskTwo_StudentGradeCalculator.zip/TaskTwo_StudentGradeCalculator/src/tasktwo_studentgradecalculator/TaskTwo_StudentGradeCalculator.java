/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tasktwo_studentgradecalculator;

import javax.swing.JOptionPane;

/**
 *
 * @author Dianca
 */
public class TaskTwo_StudentGradeCalculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
  // Define subjects
        String[] subjects = {
                "Mathematics",
                "English home language",
                "Afrikaans additional language",
                "Biology",
                "Physics",
                "Chemistry",
                "IT"
        };

        // Initialize variables
        int totalMarks = 0;
        int numSubjects = subjects.length;

        // Input marks for each subject
        for (String subject : subjects) {
            String userInput = JOptionPane.showInputDialog("Enter marks for " + subject + " (out of 100): ");
            int marks = Integer.parseInt(userInput);

            // Validate marks (0 to 100)
            if (marks < 0 || marks > 100) {
                JOptionPane.showMessageDialog(null, "Invalid marks! Please enter marks between 0 and 100.");
                return; // Exit program
            }

            totalMarks += marks;
        }

        // Calculate average percentage
        double averagePercentage = (double) totalMarks / numSubjects;

        // Determine grade based on average percentage
        char grade;
        switch ((int) averagePercentage / 10) {
            case 9:
            case 10:
                grade = 'A';
                break;
            case 8:
                grade = 'B';
                break;
            case 7:
                grade = 'C';
                break;
            case 6:
                grade = 'D';
                break;
            default:
                grade = 'F';
        }

        // Display results
        String result = "Total Marks: " + totalMarks + "\n";
        result += "Average Percentage: " + averagePercentage + "%\n";
        result += "Average Grade: " + grade;

        JOptionPane.showMessageDialog(null, result);
    }
}

