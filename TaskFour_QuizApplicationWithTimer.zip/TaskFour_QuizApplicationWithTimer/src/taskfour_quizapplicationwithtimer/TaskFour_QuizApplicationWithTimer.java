/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taskfour_quizapplicationwithtimer;

import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JOptionPane;

/**
 *
 * @author Dianca
 */
public class TaskFour_QuizApplicationWithTimer {

    /**
     * @param args the command line arguments
     */

  private static String[] questions = {
            "Biology: What is the powerhouse of the cell?",
            "Physics: What is the SI unit of force?",
            "Geography: Which is the largest ocean on Earth?",
            "History: Who was the first President of the United States?",
            "Biology: What is the process by which plants make their own food?",
            "Physics: What is the formula for calculating force?",
            "Geography: What is the capital of Japan?",
            "History: In which year did World War II end?",
            "Biology: Which gas do plants absorb during photosynthesis?",
            "Physics: What is the law of inertia?"
    };

    private static String[][] options = {
            {"Mitochondria", "Nucleus", "Ribosome", "Cell membrane"},
            {"Newton", "Joule", "Watt", "Pascal"},
            {"Atlantic Ocean", "Indian Ocean", "Pacific Ocean", "Arctic Ocean"},
            {"George Washington", "Thomas Jefferson", "John Adams", "Abraham Lincoln"},
            {"Photosynthesis", "Respiration", "Transpiration", "Digestion"},
            {"F = ma", "E = mc^2", "P = mv", "W = mg"},
            {"Seoul", "Beijing", "Tokyo", "Bangkok"},
            {"1943", "1945", "1950", "1960"},
            {"Oxygen", "Carbon dioxide", "Nitrogen", "Hydrogen"},
            {"Newton's First Law", "Newton's Second Law", "Newton's Third Law", "Archimedes' Principle"}
            // Add more options as needed
    };

      private static int[] correctAnswers = {0, 1, 2, 0, 0, 0, 2, 1, 1, 0}; // Index of the correct answer for each question

    private int currentQuestionIndex;
    private int userScore;
    private Timer timer;

    public TaskFour_QuizApplicationWithTimer() {
        this.currentQuestionIndex = 0;
        this.userScore = 0;
        this.timer = new Timer();
    }

    public void startQuiz() {
        displayQuestionWithTimer();
    }

    private void displayQuestionWithTimer() {
        displayQuestion(currentQuestionIndex);

        // Set a timer for 10 seconds to move on to the next question automatically
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                moveOnToNextQuestion();
            }
        }, 10000);
    }

    private void displayQuestion(int questionIndex) {
        StringBuilder message = new StringBuilder(questions[questionIndex] + "\n");
        String[] currentOptions = options[questionIndex];

        for (int i = 0; i < currentOptions.length; i++) {
            message.append(i + 1).append(". ").append(currentOptions[i]).append("\n");
        }

        int userChoice;
        do {
            String userInput = JOptionPane.showInputDialog(null, message, "Question " + (currentQuestionIndex + 1),
                    JOptionPane.PLAIN_MESSAGE);
            if (userInput == null) {
                // Handle if the user closes the dialog (cancel button or close button)
                System.exit(0);
            }
            userChoice = Integer.parseInt(userInput) - 1; // Adjust to zero-based index
        } while (userChoice < 0 || userChoice >= currentOptions.length);

        // Cancel the timer since the user answered before the time limit
        timer.cancel();
        timer.purge();

        checkAnswer(userChoice);
    }

    private void moveOnToNextQuestion() {
        JOptionPane.showMessageDialog(null, "Time's up! Moving on to the next question.");
        timer.cancel();
        timer.purge();
        checkAnswer(-1); // Use -1 to indicate that the user didn't answer in time
    }

    private void checkAnswer(int userChoice) {
        if (userChoice == correctAnswers[currentQuestionIndex] || userChoice == -1) {
            userScore++;
        }

        currentQuestionIndex++;

        if (currentQuestionIndex < questions.length) {
            // If there are more questions, display the next question with a timer
            displayQuestionWithTimer();
        } else {
            // If all questions are answered, display the result
            displayResult();
        }
    }

    private void displayResult() {
 StringBuilder resultMessage = new StringBuilder("Quiz completed!\nYour score: " + userScore + "/" + questions.length + "\n");

    for (int i = 0; i < questions.length; i++) {
        resultMessage.append("\nQuestion ").append(i + 1).append(": ").append(questions[i]);

        int userAnswerIndex = (i < correctAnswers.length) ? correctAnswers[i] : -1;
        String userChoice = (userAnswerIndex == -1) ? "No answer in time" : options[i][userAnswerIndex];
  //      resultMessage.append("\nYour answer: ").append(userChoice);

        if (i < correctAnswers.length) {
            String correctChoice = options[i][correctAnswers[i]];
            resultMessage.append(" (Correct Answer: ").append(correctChoice).append(")");

            if (userAnswerIndex == i) {
                resultMessage.append(" (Correct)");
            } else {
                resultMessage.append(" (Incorrect)");
            }
        } else {
            resultMessage.append(" (Correct Answer: N/A)");
            resultMessage.append(" (Incorrect)");
        }
    }

    JOptionPane.showMessageDialog(null, resultMessage.toString(), "Quiz Result", JOptionPane.INFORMATION_MESSAGE);
}

    public static void main(String[] args) {
        TaskFour_QuizApplicationWithTimer quizApp = new TaskFour_QuizApplicationWithTimer();
        quizApp.startQuiz();
    }
}